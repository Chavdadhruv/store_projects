from django.apps import AppConfig


class PredictRiskConfig(AppConfig):
    name = 'predict_risk'
