from django.apps import AppConfig


class PlantAppConfig(AppConfig):
    name = 'plant_diseases_recognition_app'
